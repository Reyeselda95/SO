package model;
/**
 * @author ALEJANDRO REYES ALBILLAR 45931406-S
 * correo ara65@alu.ua.es
 *
 */
import java.io.IOException;

/**
 * The Class Memoria.
 */
public class Memoria {
	
	/**
	 * The main method.
	 *
	 * @param args the arguments
	 * @throws NumberFormatException the number format exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@SuppressWarnings("unused")
	public static void main(String[] args) throws NumberFormatException, IOException {
		Modulos modulos = new Modulos();
	}
}
